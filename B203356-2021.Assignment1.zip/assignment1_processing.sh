#!/usr/bin/bash
# TODO handle existing subfolders silently
# TODO working dir - delete on completion - user configurable?

mkdir ~/Assignment1
cd ~/Assignment1
mkdir working

genome_name="TriTrypDB-46_TcongolenseIL3000_2019"

# Fixed data locations
source_data_location="/localdisk/data/BPSM/AY21/"
tcongo_genome_location="Tcongo_genome/${genome_name}_Genome.fasta"
fastq_data="${source_data_location}fastq/"
source_genome_location="${source_data_location}${tcongo_genome_location}.gz"
genome_bed_file="${source_data_location}${genome_name}.bed"
info_file="${fastq_data}100k.fqfiles"

# Working folder names
fastqc_working="working/fastqc"
tcongo_genome_working="working/$tcongo_genome_location"
tcongo_index_working="working/Tcongo_index"
tcongo_index_prefix="${tcongo_index_working}/Tcongolense_IL3000"
bam_working="working/mapped_sequences"
groups_working="working/groups"

# TODO if dir exists, remove it & create afresh
mkdir "$fastqc_working"
mkdir "$tcongo_index_working"
mkdir "$bam_working"
mkdir "$groups_working"
mkdir "working/Tcongo_genome"

# Summary file names
quality_summary_filename="working/fastqc_quality_summaries.txt"

# TODO if file exists, remove it & create afresh
test -f $quality_summary_filename || touch $quality_summary_filename

# Additional tweaks
threads=16

# Extract the IDs of all the qc files
file_ids=$(tail -n +2 ${info_file} | cut -f1 | sort)

# GROUPING
#awk -F '\t' '{print $1 >> $5; print $1 >> $2; print $1 >> $3; print $1 >> $4}' ${info_file}
# 1 file per sample/treatment/time combo
# we want to use the row number rather than the ID to make it easier to slice & dice the columns in gene_counts
tail -n +2 ${info_file}| awk -F '\t' -v groups="${groups_working}" '{print NR >> groups"/"$2$5$4}'

# ~ GENERATING QUALITY REPORTS ~ #
echo -e "Extracting from ${fastq_data}"
fastqc -t $threads --extract ${fastq_data}*.fq.gz -o "${fastqc_working}"

# Capture some of the specific quality-related output
# TODO process this - present to user & give options
# Create a summary file to capture quality data
while IFS= read -r file_id; do
  # First file in each pair
  echo -e "${file_id}_1" >> $quality_summary_filename
  cat "./${fastqc_working}/100k.${file_id}_1_fastqc/fastqc_data.txt" |  grep -i -w "quality" | grep -v "^#" >> "$quality_summary_filename"

  # Second file in each pair
  echo -e "${file_id}_2" >> $quality_summary_filename
  cat "./${fastqc_working}/100k.${file_id}_2_fastqc/fastqc_data.txt" |  grep -i -w "quality" | grep -v "^#" >> "$quality_summary_filename"
done <<< "$file_ids"

# TODO deal with the quality here

# ~ ALIGNMENT: ALIGNING READ PAIRS TO GENOME USING BOWTIE2 ~ #
# Build a bowtie2 index across the T congolense genome
gunzip -c "${source_genome_location}" > "${tcongo_genome_working}"
bowtie2-build --threads $threads --quiet "${tcongo_genome_working}" "$tcongo_index_prefix"

while IFS= read -r file_id ; do
  echo "Processing paired reads ${file_id}."
  m1="${fastq_data}/100k.${file_id}_1.fq.gz"
  m2="${fastq_data}/100k.${file_id}_2.fq.gz"

  bam_file="${bam_working}/${file_id}.bam"
  bowtie2 -p $threads -x $tcongo_index_prefix -1 $m1 -2 $m2 | samtools view -bS | samtools sort -o "$bam_file"
  samtools index -@ $threads "${bam_file}"
done <<< "$file_ids"

# ~ GENERATE COUNTS DATA: RUNNING BEDTOOLS ~ #
echo "Running bedtools"
bedtools multicov -bams $bam_working/*.bam -bed "$genome_bed_file" > "gene_counts.txt"

# ~ OUTPUT EXPRESSION LEVELS PER GROUP ~ #
# Each column is one of the paired reads

# ~ Generate fold change data for group-wise comparisons #
# for each group
# calculate the mean expression levels for each row (gene)
# store these as a file (later convert to variable? TODO)
# iterate through all genes, add gene name, gene description, then each group's mean to the row

